from flask import Flask, render_template, request, jsonify, redirect, url_for
import os
import threading

from backend.hub import Hub

import config


app = Flask(__name__)

print(
    f"[APP TRACE] MODULE LOAD | pid={os.getpid()} | "
    f"thread={threading.current_thread().name}",
    flush=True,
)

hub = Hub()
hub.websocket.initialize(app)

print(
    f"[APP TRACE] HUB CREATED | pid={os.getpid()} | "
    f"hub_id={id(hub)}",
    flush=True,
)

# Gunicorn imports this module instead of executing it as __main__.
# Initialize the Hub here so MQTT, telemetry, and command routing are
# available in the Render production process as well as local runs.
hub.initialize()

print(
    f"[APP TRACE] HUB INITIALIZE RETURNED | pid={os.getpid()} | "
    f"hub_id={id(hub)} | initialized={hub.initialized}",
    flush=True,
)


@app.route("/")
def index():
    return render_template("index.html")


@app.post("/command")
def command():
    """Legacy HTTP command endpoint.

    The dashboard no longer uses this route. Live browser communication
    uses the native WebSocket endpoint at /ws.
    """
    text_command = (
        request.data.decode("utf-8").strip().upper()
    )

    result = hub.handle_websocket_command(
        command=text_command,
        device=request.headers.get("X-SynaptiMesh-Device", ""),
    )

    if not result.get("ok"):
        return jsonify(result), 400

    return jsonify({
        "status": "ok",
        "command": result["command"],
    })


@app.route("/car-control")
def car_control():
    # Single unified responsive template for Desktop, Tablet, and Mobile.
    return render_template("car_control.html")


@app.route("/car-control/mobile")
def car_control_mobile():
    return redirect(url_for("car_control"), code=302)


@app.route("/car-control/desktop")
def car_control_desktop():
    return redirect(url_for("car_control"), code=302)


# ==========================================================
# MQTT CONFIGURATION
# ==========================================================

@app.get("/mqtt/config")
def mqtt_config():

    profiles = {}

    for key, profile in config.MQTT_PROFILES.items():

        profiles[key] = {
            "name": profile["name"],
            "broker": profile["broker"],
            "port": profile["port"],
        }

    current = hub.mqtt.get_config()

    return jsonify({
        "success": True,
        "current": current,
        "profiles": profiles,
    })


@app.post("/mqtt/config")
def mqtt_config_update():

    data = request.get_json(
        silent=True
    ) or {}

    profile = str(
        data.get("profile", "")
    ).strip()

    broker = str(
        data.get("broker", "")
    ).strip()

    port = data.get(
        "port",
        1883
    )

    # ------------------------------------------------------
    # Profile selection
    # ------------------------------------------------------

    if profile and profile != "custom":

        selected = config.MQTT_PROFILES.get(
            profile
        )

        if not selected:

            return jsonify({
                "success": False,
                "error": "Unknown MQTT profile."
            }), 400

        broker = selected["broker"]
        port = selected["port"]

    # ------------------------------------------------------
    # Validate custom configuration
    # ------------------------------------------------------

    if not broker:

        return jsonify({
            "success": False,
            "error": "MQTT broker is required."
        }), 400

    try:

        port = int(port)

    except (
        TypeError,
        ValueError
    ):

        return jsonify({
            "success": False,
            "error": "MQTT port must be a number."
        }), 400

    if not (
        1 <= port <= 65535
    ):

        return jsonify({
            "success": False,
            "error": "MQTT port must be between 1 and 65535."
        }), 400

    try:

        hub.mqtt.configure_broker(
            broker,
            port
        )

        return jsonify({
            "success": True,
            "config": hub.mqtt.get_config(),
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "error": str(e),
        }), 500

    

if __name__ == "__main__":
    print(config.APP_NAME)
    # Hub is initialized at module load so Gunicorn and local execution
    # share the same single initialization path.

    # Native WebSocket support is provided by Flask-Sock/simple-websocket.
    # Keep the development reloader disabled so only one Hub/MQTT instance
    # exists and duplicate MQTT connections cannot be created.
    app.run(
        host=config.HOST,
        port=config.PORT,
        debug=config.DEBUG,
        use_reloader=False,
        threaded=True,
    )
