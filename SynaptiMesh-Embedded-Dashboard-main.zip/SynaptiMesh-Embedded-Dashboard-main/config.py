import os


APP_NAME = "SynaptiMesh Master Hub"

HOST = "0.0.0.0"

PORT = int(os.environ.get("PORT", 5000))

DEBUG = False

# ==========================================================
# MQTT CONFIGURATION
# ==========================================================

MQTT_PROFILES = {
    "devops_1": {
        "name": "DevOps MQTT 1",
        "broker": "52.21.249.6",
        "port": 1883,
    },

    "devops_2": {
        "name": "DevOps MQTT 2",
        "broker": "3.210.13.251",
        "port": 1883,
    },

    "hivemq": {
        "name": "Public HiveMQ",
        "broker": "broker.hivemq.com",
        "port": 1883,
    },
}

# Default broker used when the Master Hub starts.
MQTT_PROFILE = "devops_2"

MQTT_BROKER = MQTT_PROFILES[MQTT_PROFILE]["broker"]
MQTT_PORT = MQTT_PROFILES[MQTT_PROFILE]["port"]