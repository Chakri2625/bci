# SynaptiMesh Master Hub Website - Recovery Bundle

This bundle was reconstructed from the SynaptiMesh source files available in the ChatGPT conversation/File Library after the original SSD was lost.

## Website structure

```
templates/
  index.html

static/
  css/
    style.css
  js/
    dashboard.js
  images/
    background.jpg
  vendor/
    README.txt
```

## Important recovery notes

- `index.html` and `style.css` are recovered from the Aug 19 dashboard versions stored in the project history.
- `dashboard.js` is based on the persistent-log/single-device dashboard source from the Aug 20 project history, with the later device-status snapshot/live-update behavior that was added during the subsequent debugging session.
- The dashboard uses Socket.IO over WebSocket.
- The original local `socket.io.min.js` file could not be recovered from the available uploaded/library files. The recovered `index.html` therefore loads Socket.IO 4.8.1 from the official CDN.
- The original `background.jpg` binary could not be recovered. `background.jpg` in this bundle is a visual reconstruction from a recovered dashboard screenshot so the site has a working background immediately. The original screenshot is retained as `background_source.png`.
- The original project was known to use the MQTT topics `robotcar/<DEVICE_ID>/status`, `/ack`, and `/control` and Socket.IO events for real-time dashboard updates.

## Restore

Copy the `templates` and `static` directories into the Flask application's project root. The Flask application must serve the `static` directory and render `templates/index.html`.

If the original local Socket.IO vendor file becomes available again, it can be placed at:

`static/vendor/socket.io.min.js`

and the HTML can be changed from the CDN include to the local file.
