from enum import Enum
import socket

import paho.mqtt.client as mqtt
import config


# ==========================================================
# MQTT STATE
# ==========================================================

class MQTTState(Enum):

    OFFLINE = 0
    CONNECTING = 1
    CONNECTED = 2
    RECONNECTING = 3
    ERROR = 4


# ==========================================================
# MQTT CLIENT
# ==========================================================

class MQTTClient:

    def __init__(self):

        self.client = mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION2
        )

        self.state = MQTTState.OFFLINE
        self.connected = False

        # Message listeners
        self.message_listeners = []

        # Connection listeners
        self.connection_listeners = []

        # Paho callbacks
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.client.on_message = self.on_message


    # ======================================================
    # CONNECT
    # ======================================================

    def connect(self):

        self.state = MQTTState.CONNECTING

        print("[MQTT] Connecting...")

        # Temporary Render-side TCP diagnostic. This tests whether the
        # deployed Render instance can reach the MQTT broker at all.
        # It does NOT perform an MQTT handshake. The Paho connection below
        # remains the actual MQTT connection.
        print(
            f"[MQTT DIAGNOSTIC] Testing TCP connection -> "
            f"{config.MQTT_BROKER}:{config.MQTT_PORT}"
        )

        diagnostic_socket = None

        try:

            diagnostic_socket = socket.create_connection(
                (config.MQTT_BROKER, config.MQTT_PORT),
                timeout=10
            )

            print(
                f"[MQTT DIAGNOSTIC] TCP CONNECTED -> "
                f"{config.MQTT_BROKER}:{config.MQTT_PORT}"
            )

        except Exception as e:

            print(
                f"[MQTT DIAGNOSTIC] TCP FAILED -> {e}"
            )

        finally:

            if diagnostic_socket is not None:

                try:
                    diagnostic_socket.close()
                except Exception:
                    pass

        try:

            self.client.connect(
                config.MQTT_BROKER,
                config.MQTT_PORT,
                keepalive=60
            )

            self.client.loop_start()

        except Exception as e:

            self.state = MQTTState.ERROR

            print("[MQTT] Connection Failed")
            print(e)


    # ======================================================
    # DISCONNECT
    # ======================================================

    def disconnect(self):

        self.client.loop_stop()

        self.client.disconnect()

        self.state = MQTTState.OFFLINE
        self.connected = False

        self._notify_connection_listeners(False)


    # ======================================================
    # PUBLISH
    # ======================================================

    def publish(
        self,
        topic,
        payload
    ):

        if not self.connected:

            print("[MQTT] Publish Failed (Offline)")

            return False

        result = self.client.publish(
            topic,
            payload
        )

        if result.rc == mqtt.MQTT_ERR_SUCCESS:

            print(
                f"[MQTT TX] {topic} <- {payload}"
            )

            return True

        print(
            f"[MQTT ERROR] Failed -> {topic}"
        )

        return False


    # ======================================================
    # CONNECTION STATUS
    # ======================================================

    def is_connected(self):

        return self.connected


    def get_state(self):

        return self.state


    # ======================================================
    # MESSAGE LISTENER
    # ======================================================

    def add_message_listener(
        self,
        callback
    ):

        if callback not in self.message_listeners:

            self.message_listeners.append(
                callback
            )


    def remove_message_listener(
        self,
        callback
    ):

        if callback in self.message_listeners:

            self.message_listeners.remove(
                callback
            )


    # ======================================================
    # CONNECTION LISTENER
    # ======================================================

    def add_connection_listener(
        self,
        callback
    ):

        if callback not in self.connection_listeners:

            self.connection_listeners.append(
                callback
            )


    def remove_connection_listener(
        self,
        callback
    ):

        if callback in self.connection_listeners:

            self.connection_listeners.remove(
                callback
            )


    # ======================================================
    # SUBSCRIBE
    # ======================================================

    def subscribe(
        self,
        topic
    ):

        if not self.connected:

            return

        result, _ = self.client.subscribe(
            topic
        )

        if result == mqtt.MQTT_ERR_SUCCESS:

            print(
                f"[MQTT] Subscribed -> {topic}"
            )

        else:

            print(
                f"[MQTT] Failed to subscribe -> {topic}"
            )


    # ======================================================
    # CONNECT CALLBACK
    # ======================================================

    def on_connect(
        self,
        client,
        userdata,
        flags,
        reason_code,
        properties
    ):

        if reason_code == 0:

            self.connected = True
            self.state = MQTTState.CONNECTED

            print("[MQTT] Connected")

            # ==================================================
            # ROBOT CAR STATUS
            # ==================================================

            self.subscribe(
                "robotcar/+/status"
            )

            # ==================================================
            # ROBOT CAR ACK
            # ==================================================

            self.subscribe(
                "robotcar/+/ack"
            )

            # Notify connection listeners

            self._notify_connection_listeners(
                True
            )

        else:

            self.connected = False
            self.state = MQTTState.ERROR

            print(
                f"[MQTT] Failed ({reason_code})"
            )

            self._notify_connection_listeners(
                False
            )


    # ======================================================
    # DISCONNECT CALLBACK
    # ======================================================

    def on_disconnect(
        self,
        client,
        userdata,
        flags,
        reason_code,
        properties
    ):

        self.connected = False
        self.state = MQTTState.RECONNECTING

        print("[MQTT] Disconnected")

        self._notify_connection_listeners(
            False
        )


    # ======================================================
    # MESSAGE CALLBACK
    # ======================================================

    def on_message(
        self,
        client,
        userdata,
        msg
    ):

        payload = msg.payload.decode(
            "utf-8",
            errors="replace"
        )

        # Send packet to every registered listener.
        # Message interpretation/logging belongs to TelemetryManager.

        for callback in list(
            self.message_listeners
        ):

            try:

                callback(
                    msg.topic,
                    payload
                )

            except Exception as e:

                print(
                    "[MQTT] Listener Error:"
                )

                print(e)


    # ======================================================
    # INTERNAL CONNECTION NOTIFICATION
    # ======================================================

    def _notify_connection_listeners(
        self,
        connected
    ):

        for callback in list(
            self.connection_listeners
        ):

            try:

                callback(
                    connected
                )

            except Exception as e:

                print(
                    "[MQTT] Connection Listener Error:"
                )

                print(e)