import json


# ==========================================================
# TELEMETRY MANAGER
# ==========================================================

class TelemetryManager:

    def __init__(self, socket):

        print("[Telemetry] Ready")

        self.socket = socket

        # --------------------------------------------------
        # Latest device information
        # --------------------------------------------------

        self.latest = {

            "device": "UNKNOWN",

            "state": "STOP",

            "status": "OFFLINE",

            "ack": "",

            "last_command": "",

            "front_distance": 0.0,

            "rear_distance": 0.0,

            "front_obstacle": False,

            "rear_obstacle": False,

            "wifi": "DISCONNECTED",

            "mqtt": "DISCONNECTED"
        }


    # ======================================================
    # MQTT MESSAGE HANDLER
    # ======================================================

    def handle_telemetry(
        self,
        topic,
        payload
    ):

        # One transport path: every MQTT message enters TelemetryManager
        # once, then is forwarded to browser clients through WebSocket.
        self.socket.handle_message(topic, payload)

        # ==================================================
        # ACK TOPIC
        # ==================================================

        if topic.endswith("/ack"):

            self.handle_ack(
                topic,
                payload
            )

            return


        # ==================================================
        # STATUS TOPIC
        # ==================================================

        if topic.endswith("/status"):

            self.handle_status(
                topic,
                payload
            )

            return


        # ==================================================
        # UNKNOWN TOPIC
        # ==================================================

        print(
            f"[Telemetry] Ignoring unknown topic: {topic}"
        )


    # ======================================================
    # ACK HANDLER
    # ======================================================

    def handle_ack(
        self,
        topic,
        payload
    ):

        device = self.extract_device(
            topic
        )

        ack = payload.strip()

        # ACK proves the slave is reachable through MQTT.
        self.socket.mqtt_device_status(
            device,
            "ONLINE"
        )

        # --------------------------------------------------
        # Store
        # --------------------------------------------------

        self.latest["device"] = device

        self.latest["ack"] = ack

        self.latest["last_command"] = ack


        # --------------------------------------------------
        # SINGLE ACK CONSOLE LOG
        # --------------------------------------------------

        print(
            f"[ESP32 ACK] Device: {device} | ACK: {ack}"
        )


        # --------------------------------------------------
        # Send ACK to website
        # --------------------------------------------------

        self.socket.ack({

            "device": device,

            "ack": ack,

            "topic": topic
        })


        # --------------------------------------------------
        # Also send activity log
        # --------------------------------------------------

        self.socket.activity(
            f"[ACK] {device}: {ack}"
        )


        # --------------------------------------------------
        # Update telemetry display
        # --------------------------------------------------

        self.socket.telemetry({

            "device": device,

            "ack": ack
        })


    # ======================================================
    # STATUS HANDLER
    # ======================================================

    def handle_status(
        self,
        topic,
        payload
    ):

        device = self.extract_device(
            topic
        )

        status = payload.strip()

        # Normal slave status proves the MQTT path is active.
        # OFFLINE/DISCONNECTED is treated as a broken slave link.
        mqtt_device_state = (
            "DISCONNECTED"
            if status.upper() in ("OFFLINE", "DISCONNECTED")
            else "ONLINE"
        )

        self.socket.mqtt_device_status(
            device,
            mqtt_device_state
        )

        # --------------------------------------------------
        # Store
        # --------------------------------------------------

        self.latest["device"] = device

        self.latest["status"] = status

        self.socket.update_device_status(
            device,
            status
        )


        # --------------------------------------------------
        # Determine basic state
        # --------------------------------------------------

        upper_status = status.upper()


        if "OBSTACLE" in upper_status:

            self.latest["state"] = "STOP"

        elif "FORWARD" in upper_status:

            self.latest["state"] = "FORWARD"

        elif "BACKWARD" in upper_status:

            self.latest["state"] = "BACKWARD"

        elif "LEFT360" in upper_status:

            self.latest["state"] = "LEFT360"

        elif "RIGHT360" in upper_status:

            self.latest["state"] = "RIGHT360"

        elif "LEFT" in upper_status:

            self.latest["state"] = "LEFT"

        elif "RIGHT" in upper_status:

            self.latest["state"] = "RIGHT"

        elif "STOP" in upper_status:

            self.latest["state"] = "STOP"


        # --------------------------------------------------
        # SINGLE STATUS CONSOLE LOG
        # --------------------------------------------------

        print(
            f"[ESP32 STATUS] Device: {device} | "
            f"Status: {status} | "
            f"State: {self.latest['state']}"
        )


        # --------------------------------------------------
        # Send status to website
        # --------------------------------------------------

        self.socket.telemetry({

            "device": device,

            "status": status,

            "state": self.latest["state"]
        })


        # --------------------------------------------------
        # Activity log
        # --------------------------------------------------

        self.socket.activity(
            f"[STATUS] {device}: {status}"
        )


    # ======================================================
    # DEVICE EXTRACTION
    # ======================================================

    def extract_device(
        self,
        topic
    ):

        parts = topic.split("/")


        # Expected:
        #
        # robotcar/<DEVICE_ID>/ack
        #
        # robotcar/<DEVICE_ID>/status

        if len(parts) >= 3:

            return parts[1]


        return "UNKNOWN"


    # ======================================================
    # GET LATEST
    # ======================================================

    def get_latest(self):

        return self.latest