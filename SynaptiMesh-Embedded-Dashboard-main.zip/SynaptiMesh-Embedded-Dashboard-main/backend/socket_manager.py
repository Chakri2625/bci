from flask_socketio import SocketIO


# ==========================================================
# SOCKET MANAGER
# ==========================================================

class SocketManager:

    def __init__(self):

        self.socket = SocketIO(
            cors_allowed_origins="*",
            async_mode="threading",
            allow_upgrades=False
        )

        # --------------------------------------------------
        # LATEST DEVICE STATUS
        # --------------------------------------------------
        self.device_status = {}


    # ======================================================
    # INITIALIZE
    # ======================================================

    def initialize(
        self,
        app
    ):

        self.socket.init_app(
            app
        )

        # --------------------------------------------------
        # SEND CURRENT STATE TO NEW DASHBOARD CLIENT
        # --------------------------------------------------

        @self.socket.on("connect")
        def handle_connect():

            print(
                "[SOCKET.IO] Dashboard connected"
            )

            self.socket.emit(
                "device_status_snapshot",
                self.device_status
            )


    # ======================================================
    # TELEMETRY
    # ======================================================

    def telemetry(
        self,
        data
    ):

        self.socket.emit(
            "telemetry",
            data
        )


    # ======================================================
    # ACK
    # ======================================================

    def ack(
        self,
        data
    ):

        self.socket.emit(
            "ack",
            data
        )


    # ======================================================
    # ACTIVITY
    # ======================================================

    def activity(
        self,
        data
    ):

        self.socket.emit(
            "activity",
            data
        )


    # ======================================================
    # MQTT STATUS
    # ======================================================

    def mqtt_status(
        self,
        connected
    ):

        self.socket.emit(
            "mqtt_status",
            {
                "connected":
                    connected
            }
        )


    # ======================================================
    # RAW MQTT MESSAGE
    # ======================================================
    #
    # This method does not interpret ACK/status payloads.
    # TelemetryManager remains the single message processor.
    # ======================================================

    def mqtt_message(
        self,
        topic,
        payload
    ):

        self.socket.emit(
            "mqtt_message",
            {
                "topic": topic,
                "payload": payload
            }
        )


    # Backward-compatible alias for any future caller.
    def handle_message(
        self,
        topic,
        payload
    ):

        self.mqtt_message(
            topic,
            payload
        )


    # ======================================================
    # DEVICE STATUS
    # ======================================================

    def update_device_status(
        self,
        device,
        status
    ):

        device = str(device).strip()
        status = str(status).strip()

        if not device:
            return

        self.device_status[device] = status

        self.socket.emit(
            "device_status",
            {
                "device": device,
                "status": status
            }
        )
